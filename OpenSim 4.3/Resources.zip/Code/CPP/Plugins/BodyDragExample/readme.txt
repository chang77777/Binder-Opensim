This directory contains user plugins, it is queried by the application on startup. 
This directory should be on the PATH environment variable (which should happen by default).